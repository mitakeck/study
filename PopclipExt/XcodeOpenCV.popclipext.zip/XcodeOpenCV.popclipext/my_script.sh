other_linker_flags='-lopencv_videostab\n
-lopencv_videoio\n
-lopencv_video\n
-lopencv_ts\n
-lopencv_superres\n
-lopencv_stitching\n
-lopencv_shape\n
-lopencv_photo\n
-lopencv_objdetect\n
-lopencv_ml\n
-lopencv_imgproc\n
-lopencv_imgcodecs\n
-lopencv_highgui\n
-lopencv_flann\n
-lopencv_features2d\n
-lopencv_core\n
-lopencv_calib3d'

echo $other_linker_flags